'use strict';

window.addEventListener('DOMContentLoaded', windowHandler);