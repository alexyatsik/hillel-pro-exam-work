'use strict';

function windowHandler() {

}